<?php

$host = "localhost";
$dbname = "enesaltt_prime";
$username = "enesaltt_primeuser";
$password = "enes8651768";

try{
    $db = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
}catch(Exception $e){
    die("Fatal error: ".$e->getMessage());
}
