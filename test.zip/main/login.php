<?php  
include "class.php";
echo Main::LOGIN($user,$pass,$hwid);