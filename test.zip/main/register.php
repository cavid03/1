<?php  
include "class.php";
echo Main::REGISTER($user,$pass,$hwid);